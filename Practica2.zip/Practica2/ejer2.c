#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main (int argc, char const *argv[])
{
	pid_t valRet;
	int i, st, status;

	valRet=fork();

	switch(valRet)
	{
		case -1:
			printf("Error \n");
			exit(1);
			break;
		case 0:
			printf("hijo : Soy el proceso hijo, valRet = %d\n",valRet);
			printf("hijo : Mi pid es %d, el pid de mi padre es %d\n",getpid(),getppid());
			printf("hijo:Estoy trabajando ....\n");

			for(int j=0;j<4; j++){
				sleep(1);
			   }
			printf("hijo : Dame un valor para regresarlo en el exit: ");
			scanf("%d",&st);
			printf("hijo:Listo,bye.\n");
			exit(st);
		default:
		
			printf("padre : Soy el proceso padre, valRet = %d\n",valRet);
			printf("padre:Estoy trabajando ...\n");
		for (int i=0;i< 4;i++) {
			sleep(1); }
		        printf("padre:Estoy esperando a que mi hijo termine ...\n");
			wait(&status);
			printf("padre: Mi hijo termino con el valor %d\n", WEXITSTATUS(status));
			printf("padre:Listo,bye.\n");
		        break;
		 	}
	  return 0;

}

